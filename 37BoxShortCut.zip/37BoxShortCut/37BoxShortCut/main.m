//
//  main.m
//  37BoxShortCut
//
//  Created by 卢祥庭 on 8/30/16.
//  Copyright © 2016 com.37wan.37SYTechnology. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
