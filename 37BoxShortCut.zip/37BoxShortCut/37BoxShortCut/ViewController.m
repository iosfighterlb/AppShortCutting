//
//  ViewController.m
//  37BoxShortCut
//
//  Created by 卢祥庭 on 8/30/16.
//  Copyright © 2016 com.37wan.37SYTechnology. All rights reserved.
//

#import "AppDelegate.h"
#import "SYMarqueeLabel.h"
#import "ViewController.h"
#import <AVFoundation/AVFoundation.h>

#define MainViewMarqueeTag 8001
#define DefaultScrollText @"官方客服公众号QQ：800089273，请玩家提高警惕，谨防受骗"

@interface ViewController ()  <AVCaptureMetadataOutputObjectsDelegate>
{
    AVCaptureSession * session;//输入输出的中间桥梁
}
@property (nonatomic, strong) AVCaptureVideoPreviewLayer *layer;

@property (weak, nonatomic) IBOutlet UIButton* scanButton;
@property (weak, nonatomic) IBOutlet SYMarqueeLabel* broadcaseLabel;
@property (weak, nonatomic) IBOutlet UIButton* webServerButton;


- (IBAction)scanButtonClicked:(id)sender;
- (IBAction)webServerButtonClicked:(id)sender;

@end

@implementation ViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    [self.broadcaseLabel setRate:50];
    [self.broadcaseLabel setText:DefaultScrollText];
    [self.broadcaseLabel setTapToScroll:YES];
    [self.broadcaseLabel setFadeLength:10.0f];
    [self.broadcaseLabel setTag:MainViewMarqueeTag];
    [self.broadcaseLabel setTextColor:[UIColor grayColor]];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(broadcaseLabelTap:)
                                                 name:@"SYSDK_BroadcaseLabelTap_Notificaiton" object:nil];
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
 
}


- (void)broadcaseLabelTap:(NSNotification *)notification
{
    [self shortCuttingSkipping];
}

- (void)webServerButtonClicked:(id)sender
{
    // 这里我的Mac本机IP地址是 10.4.2.12，HTTP服务默认的端口号为80 ，可以自行更改成通用的服务器托管地址.
    // 将配置文件phone_template.mobileconfig放置在 路径:/System/Library/LaunchDaemons/ 中
    [[UIApplication sharedApplication] openURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://10.4.2.12:80/phone_template.mobileconfig"]]];
}


- (IBAction)scanButtonClicked:(id)sender
{
    // Do any additional setup after loading the view, typically from a nib.
    //获取摄像设备
    AVCaptureDevice * device = [AVCaptureDevice defaultDeviceWithMediaType:AVMediaTypeVideo];
    //创建输入流
    AVCaptureDeviceInput * input = [AVCaptureDeviceInput deviceInputWithDevice:device error:nil];
    //创建输出流
    AVCaptureMetadataOutput * output = [[AVCaptureMetadataOutput alloc]init];
    //设置代理 在主线程里刷新
    [output setMetadataObjectsDelegate:self queue:dispatch_get_main_queue()];
    
    //初始化链接对象
    session = [[AVCaptureSession alloc]init];
    //高质量采集率
    [session setSessionPreset:AVCaptureSessionPresetHigh];
    
    [session addInput:input];
    [session addOutput:output];
    //设置扫码支持的编码格式(如下设置条形码和二维码兼容)
    output.metadataObjectTypes=@[AVMetadataObjectTypeQRCode,AVMetadataObjectTypeEAN13Code, AVMetadataObjectTypeEAN8Code, AVMetadataObjectTypeCode128Code];
    
    AVCaptureVideoPreviewLayer * layer = [AVCaptureVideoPreviewLayer layerWithSession:session];
    layer.videoGravity=AVLayerVideoGravityResizeAspectFill;
    layer.frame=self.view.layer.bounds;
    [self.view.layer insertSublayer:layer atIndex:0];
    
    self.layer = layer;
    //开始捕获
    [session startRunning];
}

- (void)captureOutput:(AVCaptureOutput *)captureOutput didOutputMetadataObjects:(NSArray *)metadataObjects fromConnection:(AVCaptureConnection *)connection
{
    if (metadataObjects.count > 0)
    {
        AVMetadataMachineReadableCodeObject * metadataObject = [metadataObjects objectAtIndex : 0 ];
        //输出扫描字符串
        NSLog(@"%@",metadataObject.stringValue);
        
        
        if ([metadataObject.stringValue isEqualToString:@"37boxshortcutting"])
        {
            [self captureStop];

            [self shortCuttingSkipping];
        }
        else
        {
            [self captureStop];
        }
    }
}


- (void)shortCuttingSkipping
{
    //模板位置
    NSString *templatePath = [[NSBundle mainBundle] pathForResource:@"phone_template" ofType:@"mobileconfig"];
    //目标位置
    NSString *documentsDirectory = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES) objectAtIndex:0];
    NSString *path = [documentsDirectory stringByAppendingPathComponent:@"profile.mobileconfig"];
    
    if ([[NSFileManager defaultManager] fileExistsAtPath:path])
    {   //如果httpserver的root路径下不存在这个文件，则把文件拷贝过去
        [[NSFileManager defaultManager] removeItemAtPath:path error:nil];
    }
    
    BOOL success = [[NSFileManager defaultManager] copyItemAtPath:templatePath toPath:path error:nil];
    
    __weak AppDelegate *appDelegate = (AppDelegate *)[[UIApplication sharedApplication] delegate];
    UInt16 port = appDelegate.httpServer.port;
    
    if (success)
    {
        [[UIApplication sharedApplication] openURL:[NSURL URLWithString:[NSString stringWithFormat:@"http://localhost:%u/profile.mobileconfig", port]]];
    }
    else
    {
        NSLog(@"Error generating profile");
    }
}

- (void)captureStop
{
    [session stopRunning];
    [self.layer removeFromSuperlayer];
}

@end
